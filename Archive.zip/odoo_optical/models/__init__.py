# -*- coding: utf-8 -*-
from . import config
from . import hr_employee
from . import hr_job
from . import product_inherit
from . import res_company
from . import sale_order