* Add a field with brands associated to a Customer or Supplier on
  the Customers/Suppliers Form View.
* Fix smart button alignment in brand form view
